const stage = document.querySelector("#game-stage");
const cover = document.querySelector("#game-cover");
const play = document.querySelector("#play");
const fullscreen = document.querySelector("#fullscreen");

play.addEventListener("click", () => {
  const game = document.createElement("iframe");
  game.title = "MoneyTrail game";
  game.src = "game/";
  game.allow = "autoplay; fullscreen";
  stage.append(game);
  cover.remove();
  fullscreen.hidden = !document.fullscreenEnabled;
  game.focus();
}, { once: true });

fullscreen.addEventListener("click", async () => {
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else {
      await stage.requestFullscreen();
    }
    stage.querySelector("iframe")?.focus();
  } catch (error) {
    console.warn("Full screen unavailable", error);
  }
});

document.addEventListener("fullscreenchange", () => {
  fullscreen.textContent = document.fullscreenElement ? "Exit full screen" : "Full screen";
});
