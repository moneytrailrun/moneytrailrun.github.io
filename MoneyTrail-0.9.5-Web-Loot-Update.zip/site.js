const stage = document.querySelector("#game-stage");
const cover = document.querySelector("#game-cover");
const play = document.querySelector("#play");
const fullscreen = document.querySelector("#fullscreen");
const exitExpanded = document.querySelector("#exit-expanded");

play.addEventListener("click", () => {
  primeGameFiles(true);
  document.querySelector("#game-hero").classList.add("is-playing");
  const game = document.createElement("iframe");
  game.title = "MoneyTrail game";
  game.src = "game/?canvas=916b406b072a";
  game.allow = "autoplay; fullscreen";
  stage.append(game);
  cover.remove();
  fullscreen.hidden = false;
  game.focus();
}, { once: true });

function setExpanded(expanded) {
  stage.classList.toggle("is-expanded", expanded);
  document.documentElement.classList.toggle("game-expanded", expanded);
  exitExpanded.hidden = !expanded;
  fullscreen.setAttribute("aria-expanded", String(expanded));
  if (expanded) {
    stage.querySelector("iframe")?.focus();
  } else {
    fullscreen.focus({ preventScroll: true });
  }
}

exitExpanded.addEventListener("click", () => setExpanded(false));

fullscreen.addEventListener("click", async () => {
  if (document.fullscreenElement === stage) {
    await document.exitFullscreen();
    return;
  }
  if (document.fullscreenEnabled && typeof stage.requestFullscreen === "function") {
    try {
      await stage.requestFullscreen();
      stage.querySelector("iframe")?.focus();
      return;
    } catch {
      // Safari on iPhone and some embedded browsers limit native fullscreen.
    }
  }
  setExpanded(true);
});

let landscapeLocked = false;

document.addEventListener("fullscreenchange", async () => {
  const stageIsFullscreen = document.fullscreenElement === stage;
  const orientation = window.screen.orientation;
  fullscreen.textContent = stageIsFullscreen ? "Exit full screen" : "Full screen";
  fullscreen.setAttribute("aria-expanded", String(stageIsFullscreen || stage.classList.contains("is-expanded")));

  if (!stageIsFullscreen) {
    if (landscapeLocked) orientation?.unlock?.();
    landscapeLocked = false;
    return;
  }

  try {
    if (!orientation?.lock) return;
    await orientation.lock("landscape");
    landscapeLocked = document.fullscreenElement === stage;
    if (!landscapeLocked) orientation.unlock?.();
  } catch {
    // Fullscreen stays available when the browser limits orientation locking.
  }
});

const engineURL = new URL("game/index.wasm.gz?v=fc74679e3b97", document.baseURI).href;
const packURL = new URL("game/index.pck?v=916b406b072a", document.baseURI).href;
let primed = false;
let preparedEngine;
const warmDownloads = new Map();

window.takeMoneyTrailAsset = (url) => {
  const request = warmDownloads.get(url);
  warmDownloads.delete(url);
  return request;
};

window.takeMoneyTrailEngine = (url) => {
  if (url !== engineURL) return undefined;
  const ready = preparedEngine;
  preparedEngine = undefined;
  return ready;
};

function warmDownload(url, priority) {
  const request = fetch(url, { cache: "force-cache", priority });
  warmDownloads.set(url, request);
  request.catch(() => warmDownloads.delete(url));
}

function primeGameFiles(playerStarted = false) {
  if (primed || !cover.isConnected || document.hidden) return;
  const connection = navigator.connection;
  if (!playerStarted && (connection?.saveData || (connection?.effectiveType && connection.effectiveType !== "4g"))) return;
  primed = true;
  const priority = playerStarted ? "high" : "low";
  warmDownload(packURL, priority);

  // Fast phones can compile while the player is still on the home screen.
  // Keep the download-only path on low-memory devices and old browsers.
  if (navigator.hardwareConcurrency < 4 || (navigator.deviceMemory && navigator.deviceMemory < 4) ||
      typeof DecompressionStream !== "function" ||
      typeof WebAssembly.compileStreaming !== "function") {
    warmDownload(engineURL, priority);
    return;
  }

  const wasm = fetch(engineURL, { cache: "force-cache", priority }).then((response) => {
    if (!response.ok || !response.body) throw new Error("Engine download unavailable");
    return new Response(response.body.pipeThrough(new DecompressionStream("gzip")), {
      headers: { "Content-Type": "application/wasm" },
    });
  });
  // A failed speculative request is retried by the normal game loader.
  preparedEngine = WebAssembly.compileStreaming(wasm).catch(() => undefined);
}

play.addEventListener("pointerenter", (event) => {
  if (event.pointerType === "mouse") primeGameFiles();
}, { once: true });
play.addEventListener("focus", () => primeGameFiles(), { once: true });
if ("requestIdleCallback" in window) {
  window.requestIdleCallback(() => primeGameFiles(), { timeout: 900 });
}
