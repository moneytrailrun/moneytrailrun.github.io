const stage = document.querySelector("#game-stage");
const cover = document.querySelector("#game-cover");
const play = document.querySelector("#play");
const fullscreen = document.querySelector("#fullscreen");
const exitExpanded = document.querySelector("#exit-expanded");

play.addEventListener("click", () => {
  const game = document.createElement("iframe");
  game.title = "MoneyTrail game";
  game.src = "game/?canvas=2b8cb1921a35";
  game.allow = "autoplay; fullscreen";
  stage.append(game);
  cover.remove();
  fullscreen.hidden = false;
  game.focus();
}, { once: true });

function setExpanded(expanded) {
  stage.classList.toggle("is-expanded", expanded);
  document.documentElement.classList.toggle("game-expanded", expanded);
  exitExpanded.hidden = !expanded;
  fullscreen.setAttribute("aria-expanded", String(expanded));
  if (expanded) {
    stage.querySelector("iframe")?.focus();
  } else {
    fullscreen.focus({ preventScroll: true });
  }
}

exitExpanded.addEventListener("click", () => setExpanded(false));

fullscreen.addEventListener("click", async () => {
  if (document.fullscreenElement === stage) {
    await document.exitFullscreen();
    return;
  }
  if (document.fullscreenEnabled && typeof stage.requestFullscreen === "function") {
    try {
      await stage.requestFullscreen();
      stage.querySelector("iframe")?.focus();
      return;
    } catch {
      // Safari on iPhone and some embedded browsers limit native fullscreen.
    }
  }
  setExpanded(true);
});

let landscapeLocked = false;

document.addEventListener("fullscreenchange", async () => {
  const stageIsFullscreen = document.fullscreenElement === stage;
  const orientation = window.screen.orientation;
  fullscreen.textContent = stageIsFullscreen ? "Exit full screen" : "Full screen";
  fullscreen.setAttribute("aria-expanded", String(stageIsFullscreen || stage.classList.contains("is-expanded")));

  if (!stageIsFullscreen) {
    if (landscapeLocked) orientation?.unlock?.();
    landscapeLocked = false;
    return;
  }

  try {
    if (!orientation?.lock) return;
    await orientation.lock("landscape");
    landscapeLocked = document.fullscreenElement === stage;
    if (!landscapeLocked) orientation.unlock?.();
  } catch {
    // Fullscreen stays available when the browser limits orientation locking.
  }
});

const preloadable = ["game/index.wasm.gz?v=fc74679e3b97", "game/index.pck?v=2b774641d869"];
let primed = false;
const warmDownloads = new Map();

window.takeMoneyTrailAsset = (url) => {
  const request = warmDownloads.get(url);
  warmDownloads.delete(url);
  return request;
};

function primeGameFiles() {
  if (primed || !cover.isConnected) return;
  const connection = navigator.connection;
  if (connection?.saveData || (connection?.effectiveType && connection.effectiveType !== "4g")) return;
  primed = true;
  for (const path of preloadable) {
    const url = new URL(path, document.baseURI).href;
    const request = fetch(url, { cache: "force-cache" });
    warmDownloads.set(url, request);
    request.catch(() => warmDownloads.delete(url));
  }
}

play.addEventListener("pointerenter", (event) => {
  if (event.pointerType === "mouse") primeGameFiles();
}, { once: true });
play.addEventListener("focus", primeGameFiles, { once: true });
if ("requestIdleCallback" in window) {
  window.requestIdleCallback(primeGameFiles, { timeout: 1600 });
}
