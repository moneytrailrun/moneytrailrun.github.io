(() => {
	'use strict';

	const enabled = navigator.maxTouchPoints > 0 || window.matchMedia('(any-pointer: coarse)').matches;
	window.moneyTrailTextFields = {
		enabled,
		create(label, value, limit) {
			const canvas = document.getElementById('canvas');
			const input = document.createElement('input');
			input.type = 'text';
			input.className = 'moneytrail-native-field';
			input.placeholder = label;
			input.setAttribute('aria-label', label);
			input.enterKeyHint = 'done';
			input.autocomplete = 'off';
			input.spellcheck = false;
			input.value = value;
			if (limit > 0) input.maxLength = limit;
			input.hidden = true;
			document.body.append(input);

			let bounds;
			let receiver;
			const position = () => {
				if (!bounds) return;
				const viewport = canvas.getBoundingClientRect();
				const height = viewport.height * bounds.height;
				Object.assign(input.style, {
					left: `${viewport.left + viewport.width * bounds.x}px`,
					top: `${viewport.top + viewport.height * bounds.y}px`,
					width: `${viewport.width * bounds.width}px`,
					height: `${height}px`,
					fontSize: `${Math.max(16, height * 0.34)}px`,
				});
				input.hidden = height <= 0;
			};
			const canvasResize = new ResizeObserver(position);
			canvasResize.observe(canvas);
			window.addEventListener('resize', position);
			document.addEventListener('fullscreenchange', position);
			input.addEventListener('input', () => receiver?.(input.value, false));
			input.addEventListener('change', () => receiver?.(input.value, false));
			input.addEventListener('keydown', event => {
				event.stopPropagation();
				if (event.key === 'Enter' && !event.isComposing && event.keyCode !== 229) {
					event.preventDefault();
					receiver?.(input.value, true);
					input.blur();
					canvas.focus({preventScroll: true});
				}
			});
			input.addEventListener('keyup', event => event.stopPropagation());
			return {
				setReceiver(callback) {
					receiver = callback;
				},
				place(x, y, width, height) {
					bounds = {x, y, width, height};
					position();
				},
				remove() {
					receiver = undefined;
					canvasResize.disconnect();
					window.removeEventListener('resize', position);
					document.removeEventListener('fullscreenchange', position);
					input.remove();
				},
			};
		},
	};
})();
