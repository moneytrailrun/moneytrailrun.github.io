(() => {
	'use strict';

	const DEFAULT = 'wss://money-trail-matchmaking.onrender.com/play';
	const REGIONAL = {
		europe: DEFAULT,
		america: 'wss://money-trail-matchmaking-na.onrender.com/play',
		asia: 'wss://money-trail-matchmaking-asia.onrender.com/play',
	};
	// Time-zone groups use representative coordinates from the public-domain IANA tzdb.
	const ZONES = {"europe":["Africa/Abidjan","Africa/Algiers","Africa/Bissau","Africa/Cairo","Africa/Casablanca","Africa/Ceuta","Africa/El_Aaiun","Africa/Juba","Africa/Khartoum","Africa/Lagos","Africa/Monrovia","Africa/Nairobi","Africa/Ndjamena","Africa/Sao_Tome","Africa/Tripoli","Africa/Tunis","Africa/Windhoek","America/Danmarkshavn","America/Scoresbysund","Asia/Almaty","Asia/Amman","Asia/Aqtau","Asia/Aqtobe","Asia/Ashgabat","Asia/Ashkhabad","Asia/Atyrau","Asia/Baghdad","Asia/Baku","Asia/Barnaul","Asia/Beirut","Asia/Bishkek","Asia/Damascus","Asia/Dubai","Asia/Dushanbe","Asia/Famagusta","Asia/Gaza","Asia/Hebron","Asia/Istanbul","Asia/Jerusalem","Asia/Kabul","Asia/Khandyga","Asia/Krasnoyarsk","Asia/Magadan","Asia/Nicosia","Asia/Novokuznetsk","Asia/Novosibirsk","Asia/Omsk","Asia/Oral","Asia/Qatar","Asia/Qostanay","Asia/Qyzylorda","Asia/Riyadh","Asia/Samarkand","Asia/Srednekolymsk","Asia/Tashkent","Asia/Tbilisi","Asia/Tehran","Asia/Tel_Aviv","Asia/Tomsk","Asia/Ust-Nera","Asia/Yakutsk","Asia/Yekaterinburg","Asia/Yerevan","Atlantic/Azores","Atlantic/Canary","Atlantic/Cape_Verde","Atlantic/Faeroe","Atlantic/Faroe","Atlantic/Madeira","Europe/Andorra","Europe/Astrakhan","Europe/Athens","Europe/Belfast","Europe/Belgrade","Europe/Berlin","Europe/Bratislava","Europe/Brussels","Europe/Bucharest","Europe/Budapest","Europe/Busingen","Europe/Chisinau","Europe/Dublin","Europe/Gibraltar","Europe/Helsinki","Europe/Istanbul","Europe/Kaliningrad","Europe/Kiev","Europe/Kirov","Europe/Kyiv","Europe/Lisbon","Europe/London","Europe/Madrid","Europe/Malta","Europe/Mariehamn","Europe/Minsk","Europe/Moscow","Europe/Nicosia","Europe/Paris","Europe/Podgorica","Europe/Prague","Europe/Riga","Europe/Rome","Europe/Samara","Europe/San_Marino","Europe/Saratov","Europe/Simferopol","Europe/Sofia","Europe/Tallinn","Europe/Tirane","Europe/Tiraspol","Europe/Ulyanovsk","Europe/Uzhgorod","Europe/Vatican","Europe/Vienna","Europe/Vilnius","Europe/Volgograd","Europe/Warsaw","Europe/Zaporozhye","Europe/Zurich"],"asia":["Africa/Johannesburg","Africa/Maputo","Antarctica/Casey","Antarctica/Davis","Antarctica/Macquarie","Antarctica/Mawson","Antarctica/Troll","Antarctica/Vostok","Asia/Bangkok","Asia/Calcutta","Asia/Chita","Asia/Choibalsan","Asia/Chongqing","Asia/Chungking","Asia/Colombo","Asia/Dacca","Asia/Dhaka","Asia/Dili","Asia/Harbin","Asia/Ho_Chi_Minh","Asia/Hong_Kong","Asia/Hovd","Asia/Irkutsk","Asia/Jakarta","Asia/Jayapura","Asia/Kamchatka","Asia/Karachi","Asia/Kashgar","Asia/Kathmandu","Asia/Katmandu","Asia/Kolkata","Asia/Kuching","Asia/Macao","Asia/Macau","Asia/Makassar","Asia/Manila","Asia/Pontianak","Asia/Pyongyang","Asia/Rangoon","Asia/Saigon","Asia/Sakhalin","Asia/Seoul","Asia/Shanghai","Asia/Singapore","Asia/Taipei","Asia/Thimbu","Asia/Thimphu","Asia/Tokyo","Asia/Ujung_Pandang","Asia/Ulaanbaatar","Asia/Ulan_Bator","Asia/Urumqi","Asia/Vladivostok","Asia/Yangon","Australia/ACT","Australia/Adelaide","Australia/Brisbane","Australia/Broken_Hill","Australia/Canberra","Australia/Currie","Australia/Darwin","Australia/Eucla","Australia/Hobart","Australia/LHI","Australia/Lindeman","Australia/Lord_Howe","Australia/Melbourne","Australia/NSW","Australia/North","Australia/Perth","Australia/Queensland","Australia/South","Australia/Sydney","Australia/Tasmania","Australia/Victoria","Australia/West","Australia/Yancowinna","Indian/Chagos","Indian/Maldives","Indian/Mauritius","Pacific/Apia","Pacific/Auckland","Pacific/Bougainville","Pacific/Chatham","Pacific/Efate","Pacific/Enderbury","Pacific/Fakaofo","Pacific/Fiji","Pacific/Guadalcanal","Pacific/Guam","Pacific/Kanton","Pacific/Kosrae","Pacific/Kwajalein","Pacific/Nauru","Pacific/Niue","Pacific/Norfolk","Pacific/Noumea","Pacific/Pago_Pago","Pacific/Palau","Pacific/Port_Moresby","Pacific/Rarotonga","Pacific/Samoa","Pacific/Tarawa","Pacific/Tongatapu","US/Samoa"],"america":["America/Adak","America/Anchorage","America/Araguaina","America/Argentina/Buenos_Aires","America/Argentina/Catamarca","America/Argentina/ComodRivadavia","America/Argentina/Cordoba","America/Argentina/Jujuy","America/Argentina/La_Rioja","America/Argentina/Mendoza","America/Argentina/Rio_Gallegos","America/Argentina/Salta","America/Argentina/San_Juan","America/Argentina/San_Luis","America/Argentina/Tucuman","America/Argentina/Ushuaia","America/Asuncion","America/Atka","America/Bahia","America/Bahia_Banderas","America/Barbados","America/Belem","America/Belize","America/Boa_Vista","America/Bogota","America/Boise","America/Buenos_Aires","America/Cambridge_Bay","America/Campo_Grande","America/Cancun","America/Caracas","America/Catamarca","America/Cayenne","America/Chicago","America/Chihuahua","America/Ciudad_Juarez","America/Cordoba","America/Costa_Rica","America/Coyhaique","America/Cuiaba","America/Dawson","America/Dawson_Creek","America/Denver","America/Detroit","America/Edmonton","America/Eirunepe","America/El_Salvador","America/Ensenada","America/Fort_Nelson","America/Fort_Wayne","America/Fortaleza","America/Glace_Bay","America/Godthab","America/Goose_Bay","America/Grand_Turk","America/Guatemala","America/Guayaquil","America/Guyana","America/Halifax","America/Havana","America/Hermosillo","America/Indiana/Indianapolis","America/Indiana/Knox","America/Indiana/Marengo","America/Indiana/Petersburg","America/Indiana/Tell_City","America/Indiana/Vevay","America/Indiana/Vincennes","America/Indiana/Winamac","America/Indianapolis","America/Inuvik","America/Iqaluit","America/Jamaica","America/Jujuy","America/Juneau","America/Kentucky/Louisville","America/Kentucky/Monticello","America/Knox_IN","America/La_Paz","America/Lima","America/Los_Angeles","America/Louisville","America/Maceio","America/Managua","America/Manaus","America/Martinique","America/Matamoros","America/Mazatlan","America/Mendoza","America/Menominee","America/Merida","America/Metlakatla","America/Mexico_City","America/Miquelon","America/Moncton","America/Monterrey","America/Montevideo","America/Montreal","America/New_York","America/Nipigon","America/Nome","America/Noronha","America/North_Dakota/Beulah","America/North_Dakota/Center","America/North_Dakota/New_Salem","America/Nuuk","America/Ojinaga","America/Panama","America/Pangnirtung","America/Paramaribo","America/Phoenix","America/Port-au-Prince","America/Porto_Acre","America/Porto_Velho","America/Puerto_Rico","America/Punta_Arenas","America/Rainy_River","America/Rankin_Inlet","America/Recife","America/Regina","America/Resolute","America/Rio_Branco","America/Rosario","America/Santa_Isabel","America/Santarem","America/Santiago","America/Santo_Domingo","America/Sao_Paulo","America/Shiprock","America/Sitka","America/St_Johns","America/Swift_Current","America/Tegucigalpa","America/Thule","America/Thunder_Bay","America/Tijuana","America/Toronto","America/Vancouver","America/Whitehorse","America/Winnipeg","America/Yakutat","America/Yellowknife","Antarctica/Palmer","Antarctica/Rothera","Asia/Anadyr","Atlantic/Bermuda","Atlantic/South_Georgia","Atlantic/Stanley","Brazil/Acre","Brazil/DeNoronha","Brazil/East","Brazil/West","Canada/Atlantic","Canada/Central","Canada/Eastern","Canada/Mountain","Canada/Newfoundland","Canada/Pacific","Canada/Saskatchewan","Canada/Yukon","Chile/Continental","Chile/EasterIsland","Mexico/BajaNorte","Mexico/BajaSur","Mexico/General","Pacific/Easter","Pacific/Galapagos","Pacific/Gambier","Pacific/Honolulu","Pacific/Johnston","Pacific/Kiritimati","Pacific/Marquesas","Pacific/Pitcairn","Pacific/Tahiti","US/Alaska","US/Aleutian","US/Arizona","US/Central","US/East-Indiana","US/Eastern","US/Hawaii","US/Indiana-Starke","US/Michigan","US/Mountain","US/Pacific"]};
	const delays = [0, 6000, 12000];
	const maxWait = 79000;
	let matching;

	function regionOrder(zone) {
		const preferred = Object.keys(ZONES).find(region => ZONES[region].includes(zone));
		switch (preferred) {
			case 'america': return ['america', 'europe', 'asia'];
			case 'asia': return ['asia', 'europe', 'america'];
			case 'europe': return ['europe', 'america', 'asia'];
			default: return [];
		}
	}

	function wait(ms, signal) {
		return new Promise(resolve => {
			if (signal.aborted) {
				resolve();
				return;
			}
			const timer = setTimeout(finish, ms);
			signal.addEventListener('abort', finish, {once: true});
			function finish() {
				clearTimeout(timer);
				signal.removeEventListener('abort', finish);
				resolve();
			}
		});
	}

	async function probe(endpoint, signal) {
		const url = new URL('/healthz', endpoint);
		url.protocol = url.protocol === 'wss:' ? 'https:' : 'http:';
		const request = new AbortController();
		const cancel = () => request.abort();
		signal.addEventListener('abort', cancel, {once: true});
		const timeout = setTimeout(cancel, 2000);
		const start = performance.now();
		try {
			const response = await fetch(url, {cache: 'no-store', signal: request.signal});
			if (response.ok && (await response.text()).trim() === 'ready') {
				return performance.now() - start;
			}
		} catch {
			// A sleeping or temporarily unavailable server can be retried.
		} finally {
			clearTimeout(timeout);
			signal.removeEventListener('abort', cancel);
		}
		return Infinity;
	}

	window.moneyTrailMatchmakingURL = DEFAULT;
	window.cancelMoneyTrailOnline = () => matching?.controller.abort();
	window.prepareMoneyTrailOnline = async (attempt, report, failedEndpoint = '') => {
		const previous = matching;
		previous?.controller.abort();
		const controller = new AbortController();
		const signal = controller.signal;
		const retrying = failedEndpoint && previous?.attempt === attempt;
		const excluded = retrying ? new Set(previous.excluded) : new Set();
		if (failedEndpoint) excluded.add(failedEndpoint);
		const deadline = retrying ? previous.deadline : performance.now() + maxWait;
		const state = {attempt, excluded, controller, deadline};
		matching = state;
		let zone = '';
		try {
			zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
		} catch {
			// Privacy settings can hide or override this hint.
		}
		const order = regionOrder(zone);
		const knownRegion = order.length > 0;
		const override = window.moneyTrailMatchmakingURL !== DEFAULT;
		const endpoints = (override ? [window.moneyTrailMatchmakingURL]
			: (knownRegion ? order : Object.keys(REGIONAL)).map(region => REGIONAL[region]))
			.filter(endpoint => !excluded.has(endpoint));
		const until = deadline - performance.now();
		if (!endpoints.length || until <= 0) {
			report(attempt, 'unavailable');
			return;
		}

		let selectionTimer;
		let best = Infinity;
		let selected = '';
		let releaseFallback;
		const accelerateFallback = new Promise(resolve => { releaseFallback = resolve; });
		const slow = setTimeout(() => report(attempt, 'waking'), 3000);
		const timeout = setTimeout(() => finish(selected), until);
		try {
			await Promise.all(endpoints.map(async (endpoint, rank) => {
				// Try the likely nearest server alone first. Healthy joins do not wake other regions.
				if (knownRegion && rank > 0) {
					await Promise.race([wait(delays[rank], signal), accelerateFallback]);
				}
				while (!signal.aborted) {
					const elapsed = await probe(endpoint, signal);
					if (signal.aborted) return;
					if (Number.isFinite(elapsed)) {
						if (elapsed < best) {
							best = elapsed;
							selected = endpoint;
						}
						if (endpoints.length === 1 || (knownRegion && elapsed < 250)) {
							finish(selected);
						} else if (selectionTimer === undefined) {
							releaseFallback();
							selectionTimer = setTimeout(() => finish(selected), 650);
						}
						return;
					}
					await wait(2100, signal);
				}
			}));
			if (selected && !signal.aborted) finish(selected);
		} finally {
			clearTimeout(timeout);
			clearTimeout(slow);
			clearTimeout(selectionTimer);
		}

		function finish(endpoint) {
			if (signal.aborted) return;
			controller.abort();
			if (endpoint) report(attempt, 'ready', endpoint);
			else report(attempt, 'unavailable');
		}
	};
})();
