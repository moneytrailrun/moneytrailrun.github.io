const stage = document.querySelector("#game-stage");
const cover = document.querySelector("#game-cover");
const play = document.querySelector("#play");
const fullscreen = document.querySelector("#fullscreen");

play.addEventListener("click", () => {
  const game = document.createElement("iframe");
  game.title = "MoneyTrail game";
  game.src = "game/";
  game.allow = "autoplay; fullscreen";
  stage.append(game);
  cover.remove();
  fullscreen.hidden = !document.fullscreenEnabled;
  game.focus();
}, { once: true });

fullscreen.addEventListener("click", async () => {
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else {
      await stage.requestFullscreen();
    }
    stage.querySelector("iframe")?.focus();
  } catch (error) {
    console.warn("Full screen unavailable", error);
  }
});

document.addEventListener("fullscreenchange", () => {
  fullscreen.textContent = document.fullscreenElement ? "Exit full screen" : "Full screen";
});

const preloadable = ["game/index.wasm.gz?v=fc74679e3b97", "game/index.pck?v=eb23d757421f"];
let primed = false;
const warmDownloads = new Map();

window.takeMoneyTrailAsset = (url) => {
  const request = warmDownloads.get(url);
  warmDownloads.delete(url);
  return request;
};

function primeGameFiles() {
  if (primed || !cover.isConnected) return;
  const connection = navigator.connection;
  if (connection?.saveData || (connection?.effectiveType && connection.effectiveType !== "4g")) return;
  primed = true;
  for (const path of preloadable) {
    const url = new URL(path, document.baseURI).href;
    const request = fetch(url, { cache: "force-cache" });
    warmDownloads.set(url, request);
    request.catch(() => warmDownloads.delete(url));
  }
}

play.addEventListener("pointerenter", (event) => {
  if (event.pointerType === "mouse") primeGameFiles();
}, { once: true });
play.addEventListener("focus", primeGameFiles, { once: true });
if ("requestIdleCallback" in window) {
  window.requestIdleCallback(primeGameFiles, { timeout: 1600 });
}
